<?php
// test_conn.php
phpinfo();
// Tambahkan kode untuk menguji koneksi di bawah ini
// require_once 'config.php';
// if (isset($conn)) echo "<h1>Koneksi Berhasil!</h1>";
?>