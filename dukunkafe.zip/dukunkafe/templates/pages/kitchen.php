
<?php

// This is a standalone page for the kitchen display
$title = 'Kitchen Display';

// No specific data needed from PHP on initial load, 
// everything will be fetched via AJAX.

require __DIR__ . '/kitchen.view.php';
