﻿<?php
require_once __DIR__ . '/helpers.php';
require_license();
require_login();
?>
